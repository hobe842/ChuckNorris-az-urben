﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Játék

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer jatekTimer = new DispatcherTimer();
        bool moveLeft, moveRight;
        List<Rectangle> asd = new List<Rectangle>();
        Random rand = new Random();


        int enemySpriteCounter; 
        int enemyCounter = 100; 
        int jatekosSpeed = 15; 
        int limit = 50;
        int pontt = 0; 
        int sebzes = 0; 

        Rect jatekosHitBox;


        public MainWindow()
        {
            InitializeComponent();

            jatekTimer.Interval = TimeSpan.FromMilliseconds(20);
            jatekTimer.Tick += gameEngine;
            jatekTimer.Start();
            MyCanvas.Focus();


            ImageBrush bg = new ImageBrush();
            bg.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/letöltés.png"));
            bg.TileMode = TileMode.Tile;
            bg.Viewport = new Rect(0, 0, 0.20, 0.20);

            bg.ViewportUnits = BrushMappingMode.RelativeToBoundingBox;
            MyCanvas.Background = bg;
            ImageBrush playerImage = new ImageBrush();

            playerImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/images (13).jpg"));

            jatekos.Fill = playerImage;
        }

        
        private void makeEllenségek()
        {

            ImageBrush enemySprite = new ImageBrush();
            enemySpriteCounter = rand.Next(1, 10);

            switch (enemySpriteCounter)
            {
                case 1:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/1.jpg"));
                    break;
                case 2:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/2.jpg"));
                    break;
                case 3:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/3.jpg"));
                    break;
                case 4:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/4.jpg"));
                    break;
                case 5:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/5.jpg"));
                    break;
                case 6:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/6.jpg"));
                    break;
                case 7:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/7.jpg"));
                    break;
                case 8:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/8.jpg"));
                    break;
                case 9:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Képek/9.jpg"));
                    break;
                default:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/1.jpg"));
                    break;
            }

            Rectangle newEnemy = new Rectangle
            {
                Tag = "ellenseg",
                Height = 80,
                Width = 100,
                Fill = enemySprite
            };
            Canvas.SetBottom(newEnemy, -95); 
            Canvas.SetLeft(newEnemy, rand.Next(30, 600));
            MyCanvas.Children.Add(newEnemy);
            GC.Collect(); 
        }

        private void AKeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Left)
            {
                moveLeft = true;
            }
            if (e.Key == Key.Right)
            {
                moveRight = true;
            }
        }

        private void AKeyUp(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Left)
            {
                moveLeft = false;
            }
            if (e.Key == Key.Right)
            {
                moveRight = false;
            }

            if (e.Key == Key.Space)
            {
                Rectangle newBullet = new Rectangle
                {
                    Tag = "lovedek",
                    Height = 60,
                    Width = 5,
                    Fill = Brushes.White,
                    Stroke = Brushes.Blue
                };

                Canvas.SetBottom(newBullet, Canvas.GetBottom(jatekos) - newBullet.Height);
                Canvas.SetLeft(newBullet, Canvas.GetLeft(jatekos) + jatekos.Width / 2);

                MyCanvas.Children.Add(newBullet);
            }
        }

        private void gameEngine(object sender, EventArgs e)
        {
            jatekosHitBox = new Rect(Canvas.GetLeft(jatekos), Canvas.GetBottom(jatekos), jatekos.Width, jatekos.Height);
            enemyCounter--;
            pontok.Content = "Pontok: " + pontt;
            sebzés.Content = "Kapott sérülés: " + sebzes;
            if (enemyCounter < 0)
            {
                makeEllenségek();
                enemyCounter = limit;
            }
            if (moveLeft && Canvas.GetLeft(jatekos) > 0)
            {
              
                Canvas.SetLeft(jatekos, Canvas.GetLeft(jatekos) - jatekosSpeed);
            }
            if (moveRight && Canvas.GetLeft(jatekos) + 90 < Application.Current.MainWindow.Width)
            {
              
                Canvas.SetLeft(jatekos, Canvas.GetLeft(jatekos) + jatekosSpeed);
            }
            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                
                if (x is Rectangle && (string)x.Tag == "lovedek")
                {
                    
                    Canvas.SetBottom(x, Canvas.GetBottom(x) - 40);                    
                    Rect bullet = new Rect(Canvas.GetLeft(x), Canvas.GetBottom(x), x.Width, x.Height);
                    if (Canvas.GetBottom(x) < 10)
                    {
                        
                        asd.Add(x);
                    }                    
                    foreach (var y in MyCanvas.Children.OfType<Rectangle>())
                    {
                        
                        if (y is Rectangle && (string)y.Tag == "ellenseg")
                        {
                            
                            Rect enemy = new Rect(Canvas.GetLeft(y), Canvas.GetBottom(y), y.Width, y.Height);
                            if (bullet.IntersectsWith(enemy))
                            {

                                asd.Add(x); 
                                asd.Add(y); 
                                pontt++; 
                            }
                        }

                    }
                }

                if (x is Rectangle && (string)x.Tag == "ellenseg")
                {
                    Canvas.SetBottom(x, Canvas.GetBottom(x) + 10);
                    Rect enemy = new Rect(Canvas.GetLeft(x), Canvas.GetBottom(x), x.Width, x.Height);                   
                    if (Canvas.GetBottom(x) + 125 > 700)
                    {
                        
                        asd.Add(x);
                        sebzes += 4;
                    }
                    if (jatekosHitBox.IntersectsWith(enemy))
                    {
                        sebzes += 15;
                        asd.Add(x);
                    }
                }
            }
            if (pontt > 5)
            {
                limit = 20; 
                
            }

            
            if (sebzes > 99)
            {
                jatekTimer.Stop();
                sebzés.Content = "Kapott sebzés: 100";
                sebzés.Foreground = Brushes.Red;
                if( pontt < 20)
                {
                    MessageBox.Show("Gratulálok Közlegény Chuck Norris!" + Environment.NewLine + "Megöltél " + pontt + " ellenséget");
                }
                else if(pontt < 100)
                {
                    MessageBox.Show("Gratulálok Betyár Chuck Norris!" + Environment.NewLine + "Megöltél " + pontt + " ellenséget");
                }
                else if( pontt < 200)
                {
                    MessageBox.Show("Gratulálok Csillagharcos Chuck Norris!" + Environment.NewLine + "Megöltél " + pontt + " ellenséget");
                }
                else
                {
                   MessageBox.Show("Gratulálok Halál Illuminate Jedi Chuck Norris!" + Environment.NewLine + "Megöltél " + pontt + " ellenséget");
                }
                

            }

            foreach (Rectangle y in asd)
            {
                MyCanvas.Children.Remove(y);
            }


        }

    }
}